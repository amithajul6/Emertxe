/* 
 * File:   adc.h
 * Author: amitha
 *
 * Created on June 15, 2023, 7:34 PM
 */
#ifndef ADC_H
#define	ADC_H

void init_adc(void);
unsigned short read_adc(void);

#endif	/* ADC_H */