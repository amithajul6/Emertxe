/* 
 * File:   timers.h
 * Author: amitha
 *
 * Created on June 15, 2023, 7:37 PM
 */

#ifndef TIMERS_H
#define	TIMERS_H

void init_timer2(void);

#endif	/* TIMERS_H */
