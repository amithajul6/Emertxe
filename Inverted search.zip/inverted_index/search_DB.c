#include "invertedIndex.h"
//function definition to search word in database
int search_DB(wlist_t **head, char *word)
{
	//variable declaration
	int i=0;
	//checking head is empty or not
	if( *head == NULL)
		return EMPTYLIST;
	//loop iterates upto size
	while(i<SIZE)
    
    {
		wlist_t *w_temp = head[i];
		//loop run untill it reach the null
        while(w_temp)
        {
			if(strcmp(w_temp -> word, word) == 0)
			{
				printf(RED "The word" RESET" "GREEN"%s"RESET" "RED" is present in the following files : \n" RESET,word);
				file_table_t *f_temp = w_temp -> t_link;
	            while(f_temp)
				{
					//print file name and word count if it is present in database
					printf("%s(%d times)\n",f_temp -> f_name, f_temp -> w_count);
		            f_temp = f_temp -> link;
	            }       
				return SUCCESS;
			}
		    w_temp=w_temp -> link;
	    }
		i++;
    }
	//if word not present in database printing error message
	printf(RED "ERROR : The word" RESET""GREEN" %s"RESET" "RED" is not found in the database \n" RESET,word);
	return NOT_PRESENT; 
}

	




