#include "invertedIndex.h"

//function definition to insert file
int insert_at_last_main(wlist_t **head, char *word, char *f_name)
{
	wlist_t *new = malloc(sizeof(wlist_t));
	// Check the node is created
	if(new == NULL)
	    return FAILURE;
	
	// Update the file count = 1, word with given word, link = NULL
	new -> f_count = 1;
	
	
	strcpy(new -> word, word);
	new -> t_link = NULL;
	
	update_link_table(&new, f_name);

	// Check the list is empty or not
	if (*head == NULL)
	{
		*head = new;
		return SUCCESS;
	}
	wlist_t *temp = *head;

	//Traverse till last and establish the link b/w last and new node.
	while(temp -> link)
	{
	    temp = temp -> link;
	}
	temp -> link = new;
	return SUCCESS;
}
