/*Documentation
Name                 : Amitha Gondesi
Date                 : 19-04-2023
TITLE                : INVERTED SEARCH 
Description          : The purpose of storing an index is to optimize speed and performance in finding relevant docum ents for a search query. 
			           Without an index, the search engine would scan every document in the corpus, which would require considerable time and computing                        power.
Prerequisite	     : Hashing,Single linked list
Sample input         : passing files through command line
Documentation*/

#include "invertedIndex.h"

int main(int argc, char *argv[])
{
     

	//Checking CLA not passed
	if (argc == 1)
	{
		printf( RED "Error: No filenames passed\nUsage: ./inverted_index.out <file1> <file2> ...\n" RESET );
		return FAILURE;
	}

	file_node_t *file_head = NULL;

	validate_n_store_filenames(&file_head, argv + 1);
	if (file_head == NULL)
	{
		//printf( RED "No files are valid\n" RESET );
		return FAILURE;
	}
	
	wlist_t *HT_head[SIZE] = {NULL};
	
	int choice;
	char check = 'y';
	
	while(check == 'Y' || check == 'y')
	{
    	    //Display the menu to user
    	    //1. Create Database
    	    //2. Display Databas
    	    //3. Search Database
    	    //4. Update Database
    	    //5. Save Database
	    printf( BLUE "1. Create Database \n2. Display Database\n3. Search Database\n4. Update Database\n5. Save Database\n6.Exit\n" RESET );
	    
	    printf( RED "Please Enter your choice : " RESET );
	    scanf("%d", &choice);
    
	    switch(choice)
	    {
			//calling creating database function
		case 1:
    		    create_DB(file_head, HT_head);
    		    break;
				//calling display function
    		case 2:
    		    display_DB(HT_head);
    		    break;
    
		case 3:
				//declaring word variable and getting word from user
    		    printf( BLUE "Enter the word to search : " RESET );
    		    char word[NAMELENGTH];
    		    scanf("%s", word);
				//calling search function
    		    search_DB(HT_head, word);
    		    break;
    
		case 4://declaring variable and getting update from user
    		    printf( BLUE "Enter the file name to update : " RESET );
    		    char fname[NAMELENGTH];
    		    scanf("%s", fname);
				//calling update_Db function
    		    update_DB(&file_head, HT_head, fname);
		    break;
		
		case 5://declaring variable and getting file name from user
    		    printf( BLUE "Enter the file name to save : " RESET );
		    char s_fname[NAMELENGTH];
    		    scanf("%s", s_fname);
				//calling save database function
    		    save_DB(HT_head, s_fname);
		    break;
	
		case 6:
		   exit(SUCCESS) ;
		default:
		    printf( RED "ERROR : Invalid option!! \n" RESET );
		   
	    }
	
	printf("Do you want to continue(y/Y) : ");
	scanf(" %c", &check);
	}
	return SUCCESS;
}

