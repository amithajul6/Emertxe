#include "invertedIndex.h"

//function definition to display data in database
int display_DB(wlist_t **head)
{
    //declaring variables
	int i = 0, flag = 0;
   //loop itreates upto size
    while( i < SIZE)
    {
        wlist_t *temp = NULL;

        if (head[i] != NULL) {
            printf(BLUE "[%d]  " RESET, i);
            temp = head[i];
            file_table_t *T_temp = temp->t_link;
            flag = 0;

            while (temp) 
	    {
                if (flag == 0)
                    printf( GREEN "\t[%s]" RESET, temp->word);
                else
                    printf(GREEN "\t[%s]" RESET, temp->word);

                printf( RED "\t%d" RESET, temp->f_count);
		printf("\tFiles(s) : File:");

                while (T_temp)
	       	    {
                    printf(GREEN "\t%s" RESET" "RED":%d "RESET" times", T_temp->f_name, T_temp->w_count);
					if(T_temp -> link == NULL)
			        printf("\t-> NULL");
		            else
			        printf("\t: File :");
					     T_temp = T_temp->link;
                }
                printf("\n");

                temp = temp->link;

                if (temp != NULL)
	       	{
                    T_temp = temp->t_link;
                }
                flag = 1;
            }
        }
		//incrementing i
		i++;
    }
    return SUCCESS;
}

