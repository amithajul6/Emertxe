#!/bin/bash

<<Doc
Name            : Amitha Gondesi
Date            : 25-03-2023
Description     : write a script command line test
Sample input    : bash cmlproject.sh
Sample output   : Enter the option
				  1.Signup
				  2.Signin
				  3.Exit
Doc

echo -e "\e[1;36mHI WELCOME TO COMMAND LINE TEST \e[0m"

usernames=(`cat user.csv`) #store usernames in array
password=(`cat password.csv`) #store passwords in array
check=0
flag=0
    #printing option to user
	echo "1.Sign up , 2.Signin , 3.exit"
	read -p "enter option:" option
	case $option in #select option by user

         #Signup case
		1)  while [ $check -eq 0 ] #using while for repeattaion
        do
           read -p "Enter the username:" user_name #reading username from the user
           for i in ${usernames[@]} #using for loop for checking the user exist or not
           do
             if [ $i != $user_name ]  #checking the condition for user
              then
                 check=1
			 else
				 check=0
				break
                fi
            done
			if [ $check -ne 1 ] #check condition
			then
				echo "Error : username already exists"
				echo "        enter different username"
			fi
		done
		while [ $flag -eq 0 ] #loop repeat from strating if any errors occurs
		do
			echo "enter your password" #read password from user
			read -s password
			echo "reenter your password"
			read -s confpassword
			if [ $password = $confpassword ]
			then
				echo "$user_name" >> user.csv #usernames are stored in user.csv file
				echo "$password" >> password.csv #passwords are stored in password.csv file
				flag=1
			else
				echo "password didnt match. re enter password"
				echo
				flag=0;
			fi
		done
		;;
        #Signin case
		2)echo "Signin"
			while [ $check -eq 0 -o $check -eq 2 ] #loop for repeation
			do
				echo -n "username:" #reading username from user
				read user_name
				length=${#usernames[@]} #store lenth of usernames in array
				for i in `seq 0 $(($length-1))` #loop runs upto length -1 times
				do
					if [ ${usernames[$i]} = ${user_name} ] #checking usersnames available or not
					then
						echo "enter password:"
						read -s password #read password from user
						if [ $password = ${password[$i]} ] #checking password is available or not
						then
							check=1 #changing count=1 if password matched with its corresponding username
							break
						else
							check=2 #if password dosen't match
							break
						fi
					else
						check=0 #check if user dosen't match
					fi
				done
				if [ $check -eq 1 ] #checking value of count
				then
					echo -e "sigined in successfully"

			echo " "
			echo "a-take test , b-exit"
			read -p "enter choice:" choice
			case $choice in
			a) echo "take test"
			lines=`wc -l < questionbank.txt` #store number of lines in questionbank.txt into array
			for j in `seq 5 5 $lines` #loop execute till last question with options
			do
			echo -e "\e[1m"
			head -$j questionbank.txt | tail -5 #showing question with 4 options
			echo -e "\e[0m"
			for i in `seq 10 -1 1` #loop run time for each question
			do
			echo -ne "\renter the option: $i" #printing last updated value
			read -t 1 opt #read answer from user
			if [ -n "$opt" ] #checking string length > 0 or not
			then
			break # break loop if user enter option
			else
			    opt="e" #assigning if user timelit is over
			fi
		done
		echo "$opt" >> userans.txt # storing user answers into userans.txt
      done
		 echo -e "\e[32m           <.....................TEST COMPLETED...............>"
		 echo -e "\e[0m"
		 sel=y #initializing variable
	     read -p "do you want to display result ? (y/n)"sel  # prompting user to display the result
		 while [ $sel = y ] #loops runs for user select y
		 do
		 case $sel in
		 y)
		  user_answer=(`cat userans.txt`) #store user answers in array
		  correct_answer=(`cat correctans.txt`) #store correct answers in array
			  count=0 ; total=0
		  echo -e "\e[32m             <<<<<<<<<<<<<<<<<<<<RESULT>>>>>>>>>>>>>>>>>>"
		  echo -e "\e[0m"
		 for i in `seq 5 5 $lines` #loop for displaying each question
		 do
		for var in $i #loop for displaying each question with answer
		do
		echo
		head -$i questionbank.txt | tail -5 #question display
		echo
		if [ ${correct_answer[$count]} = ${user_answer[$count]} ] #compare user and correct answers
		 then
		 echo -e "\e[32mcorrect answer \e[0m " #print correct answer
		let total=$total+1 #increment total value
		elif [ ${user_answer[$count]} = e ] #checking for timeout
		then
		echo -e "\e[33mtime out \e[0m " #display time out
		else
		echo -e "\e[1mYour answer : ${user_answer[$count]}"
		#display correct answer
		echo -e "correct answer : ${correct_answer[$count]} \e[0m"
		fi
		let count=$count+1 #increment count value
		 done
	 done
	   echo -e "\e[32m total marks = $total/$count \e[0m " #printing total marks
    	;;
esac
break
done
;;
esac
elif [ $check -eq 2 ] #checking count = 2 or not
 then
echo "password incorrect please enter correct password"
else
	echo " username incorrect please enter correct username"
fi
done
;;
esac
