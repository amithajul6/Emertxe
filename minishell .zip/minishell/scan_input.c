#include "main.h"

//global variable to store  PID of child process
pid_t pid;

void scan_input(char *prompt, char *input_string)
{
    char *command = '\0';
    int command_type, status;

    while (1)
    {
        //display the prompt
        printf(ANSI_COLOR_RED "[%s]$" ANSI_COLOR_GREEN, prompt);
		//clear the output buffer
        fflush(stdout);
        //read the input from the user
		scanf("%[^\n]s",input_string);
		//clear the input buffer
		getchar();

        //customize the prompt
        if (!strncmp("PS1=", input_string, 4))
        {
            if (input_string[4] != ' ')
            {
                strcpy(prompt, &input_string[4]);
				//clear the input string
				memset(input_string,'\0',25);
                continue;
            }
            printf(ANSI_COLOR_RED "ERROR : Command not found\n"ANSI_COLOR_RESET);
        }
        //to get the command
        command = get_command(input_string);
		printf(ANSI_COLOR_BLUE"command is" ANSI_COLOR_CYAN "%s" ANSI_COLOR_RESET "\n",command);
        command_type = check_command_type(command);
		printf(ANSI_COLOR_MAGENTA "command_type is" ANSI_COLOR_CYAN "%d" ANSI_COLOR_GREEN "\n", command_type);

        if (command_type == EXTERNAL)
        {
            pid = fork();
         
            if (pid == 0)
            {
                int ret= system(input_string);
                if (ret == 0)
                {
                    exit(0);
                }
				else
					exit(1);
			}
			else if(pid > 0)
			{
				wait(&status);
				if(WIFEXITED(status))
					printf(ANSI_COLOR_YELLOW "Child with pid" ANSI_COLOR_GREEN "%d" ANSI_COLOR_YELLOW "terminated normally \n",pid);
			}
            else
            {
				printf(ANSI_COLOR_RED "ERROR : Fork system call failed\n" ANSI_COLOR_RESET);
                exit(2);
            }
        }
        //call the function to implement echo commands
        echo(input_string, status);
		//call the function to implement builtin commands
        execute_internal_commands(input_string);
    }
}
