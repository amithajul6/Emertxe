#include "main.h"

void signal_handler(int sig_num)
{
	pid_t pid;
    if (sig_num == SIGINT)
    {
        //handle SIGINT (Ctrl-C) signal
        if (pid > 0)
        {
            //send SIGINT to child process
            kill(pid, SIGINT);
        }
        else
        {
            //Re-display the prompt
            printf("\n");
        }
    }
    else if (sig_num == SIGTSTP)
    {
        //handle SIGTSTP (Ctrl-Z) signal
        if (pid > 0)
        {
            //send SIGTSTP to child process
            kill(pid, SIGTSTP);
			//display the PID of the child process
            printf("Child process stopped.PID:%d\n", pid);
        }
    }
	else if (sig_num == SIGCONT) 
	{
        //handle SIGCONT (continue) signal
        if (pid > 0) 
		{
            //resume the stopped child process
            kill(pid, SIGCONT);
        }
    }
}	

